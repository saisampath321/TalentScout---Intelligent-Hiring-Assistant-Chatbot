# TalentScout - Intelligent Hiring Assistant Chatbot

TalentScout is a fictional recruitment agency specializing in technology placements. This chatbot streamlines the initial screening process by collecting key candidate information and generating technical questions tailored to their declared tech stack.

## 🚀 Features

- 📋 Collects candidate details:
  - Full Name
  - Email
  - Phone Number
  - Years of Experience
  - Desired Position(s)
  - Location
  - Tech Stack

- 🧠 Generates 3–5 relevant technical questions based on candidate's tech stack using a local LLM (LLaMA3 via Ollama).

- 💬 Interactive, context-aware conversation flow via Streamlit interface.

## 🛠️ Tech Stack

- Python
- Streamlit
- Ollama (LLaMA3)
- Local LLM serving (no OpenAI or HuggingFace API required)

## 🧾 Installation

1. **Install dependencies**:
    ```bash
    pip install -r requirements.txt
    ```

2. **Run the LLaMA3 model using Ollama**:
    ```bash
    ollama run llama3
    ```

3. **Launch the chatbot**:
    ```bash
    streamlit run app.py
    ```

## 📂 Project Structure

```
.
├── app.py                # Main Streamlit UI
├── utils/
│   └── llm.py            # Handles LLM request to Ollama
├── requirements.txt
└── README.md
```

## ✅ Assignment Goals Met

- ✅ Information collection for hiring
- ✅ Technical question generation based on tech stack
- ✅ Local deployment using open LLM
- ✅ Clean Streamlit interface
- ✅ No paid API used (uses local Ollama with llama3)

## 📌 Note
Make sure Ollama is installed and running on your system before starting the app. Visit [https://ollama.com](https://ollama.com) for installation instructions.

---

**Submitted For**: AI/ML Internship Assignment – "TalentScout"